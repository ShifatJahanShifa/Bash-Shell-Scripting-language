
#! /usr/bin/bash

BIN_DIR="$HOME/RecycleBin"
ORG=$(pwd)

cd $BIN_DIR
current_date=$(date +%Y-%m-%d)
echo $current_date


old_files=$(find . -type f -mtime +10)


for file in $old_files; do
  #echo " file $file"
  rm $file 
done

cd $ORG
